import { useState, useEffect } from 'react';

export default function App() {
  const [progress, setProgress] = useState(0);
  const [loadingText, setLoadingText] = useState('Inicializando a inteligência');
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    const loadingMessages = [
      'Inicializando a inteligência',
      'Carregando módulos',
      'Preparando experiência',
      'Quase lá...',
    ];

    const interval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + Math.random() * 15;
        if (newProgress >= 100) {
          clearInterval(interval);
          setIsComplete(true);
          return 100;
        }
        // Atualiza o texto de carregamento baseado no progresso
        const messageIndex = Math.min(
          Math.floor((newProgress / 100) * loadingMessages.length),
          loadingMessages.length - 1
        );
        setLoadingText(loadingMessages[messageIndex]);
        return newProgress;
      });
    }, 300);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Background texturizado creme/bege */}
      <div 
        className="absolute inset-0 bg-[#F5F0E8]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
          opacity: 0.4,
        }}
      />
      
      {/* Gradiente suave sobre o background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#F5F0E8] via-[#FDF8F0] to-[#F5F0E8]" />

      {/* Conteúdo centralizado */}
      <div className="relative z-10 flex min-h-screen flex-col items-center justify-center px-6">
        {/* Logo do abacaxi */}
        <div className="mb-8 animate-pulse">
          <img
            src="/images/nutrivision-logo.png"
            alt="NutriVision Logo"
            className="h-32 w-32 object-contain drop-shadow-lg"
          />
        </div>

        {/* Título NutriVision */}
        <h1 className="mb-2 text-4xl font-bold tracking-tight text-[#1B5E20]">
          NutriVision
        </h1>

        {/* Subtítulo */}
        <p className="mb-16 text-lg text-[#4A4A4A]">
          O editorial orgânico selecionado
        </p>

        {/* Barra de progresso */}
        <div className="w-full max-w-xs">
          <div className="relative h-2 overflow-hidden rounded-full bg-[#D4D4D4]">
            <div
              className="absolute left-0 top-0 h-full rounded-full bg-gradient-to-r from-[#1B5E20] to-[#2E7D32] transition-all duration-300 ease-out"
              style={{ width: `${Math.min(progress, 100)}%` }}
            />
          </div>

          {/* Texto de carregamento */}
          <p className={`mt-4 text-center text-sm font-medium transition-opacity duration-300 ${
            isComplete ? 'opacity-0' : 'opacity-100'
          } text-[#5A5A5A]}`}>
            {loadingText}
          </p>
        </div>

        {/* Mensagem de conclusão (aparece quando completo) */}
        <div className={`absolute inset-0 z-20 flex items-center justify-center bg-[#F5F0E8] transition-opacity duration-500 ${
          isComplete ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}>
          <div className="text-center">
            <h2 className="text-2xl font-semibold text-[#1B5E20]">
              Bem-vindo ao NutriVision!
            </h2>
            <p className="mt-2 text-[#4A4A4A]">
              Sua experiência orgânica está pronta.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
